// FIX: Update import path for types.
import type { User, Website } from "../types/index";

// Type definition for the sql.js library, which is loaded from a script tag
declare const initSqlJs: (config: { locateFile: (file: string) => string }) => Promise<any>;

let db: any = null;

const DB_NAME = "app_db";
const DB_STORE_NAME = "sqlite_db";
const DB_VERSION = 1;

/**
 * Opens a connection to the IndexedDB.
 */
function openIdb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(new Error("Failed to open IndexedDB."));
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(DB_STORE_NAME)) {
        db.createObjectStore(DB_STORE_NAME);
      }
    };
  });
}

/**
 * Loads the SQLite database from IndexedDB.
 */
async function loadDbFromIdb(): Promise<Uint8Array | null> {
  const idb = await openIdb();
  return new Promise((resolve, reject) => {
    const transaction = idb.transaction(DB_STORE_NAME, "readonly");
    const store = transaction.objectStore(DB_STORE_NAME);
    const request = store.get("db_file");
    request.onerror = () => reject(new Error("Failed to read from IndexedDB."));
    request.onsuccess = () => resolve(request.result || null);
  });
}

/**
 * Saves the SQLite database to IndexedDB.
 */
export async function saveDbToIdb() {
  if (!db) return;
  const idb = await openIdb();
  const data = db.export();
  return new Promise<void>((resolve, reject) => {
    const transaction = idb.transaction(DB_STORE_NAME, "readwrite");
    const store = transaction.objectStore(DB_STORE_NAME);
    const request = store.put(data, "db_file");
    request.onerror = () => reject(new Error("Failed to write to IndexedDB."));
    request.onsuccess = () => resolve();
  });
}


const seedWorkflowSteps = () => {
    const defaultSteps = [
        { key: 'cleanClosingStock', name: 'Clean Closing Stock', desc: 'Filters invalid rows and sanitizes numeric values from the closing stock report.', order: 1, enabled: 1, mandatory: 1 },
        { key: 'deduplicateClosingStock', name: 'Deduplicate Stock Items', desc: 'Removes duplicate stock items, keeping the one with the highest MRP and stock quantity.', order: 2, enabled: 1, mandatory: 0 },
        { key: 'cleanItemDirectory', name: 'Clean Item Directory', desc: 'Sanitizes discount percentages and MRP values from the item directory.', order: 3, enabled: 1, mandatory: 1 },
        { key: 'renameColumns', name: 'Rename Columns', desc: 'Renames source columns (e.g., "ITEM CODE") to their final format (e.g., "SKU").', order: 4, enabled: 1, mandatory: 1 },
        { key: 'applyDiscounts', name: 'Apply Discounts', desc: 'Looks up and applies discounts from the item directory to the stock data.', order: 5, enabled: 1, mandatory: 1 },
        { key: 'calculateNewSalePrice', name: 'Calculate Final Sale Price', desc: 'Calculates the new sale price based on the old sale price and the applied discount.', order: 6, enabled: 1, mandatory: 1 },
        { key: 'finalizeData', name: 'Finalize Data Structure', desc: 'Removes temporary columns (like "DISCOUNT") to prepare the final output.', order: 7, enabled: 1, mandatory: 1 },
    ];

    const stmt = db.prepare("INSERT INTO workflow_steps (step_key, step_name, description, step_order, is_enabled, is_mandatory) VALUES (?, ?, ?, ?, ?, ?)");
    try {
        defaultSteps.forEach(step => {
            stmt.run([step.key, step.name, step.desc, step.order, step.enabled, step.mandatory]);
        });
    } finally {
        stmt.free();
    }
};

/**
 * Creates the database schema and seeds it with initial data.
 */
function setupSchemaAndSeed() {
    if (!db) return;
    
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            password TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('admin', 'user')),
            syncsRemaining INTEGER NOT NULL,
            maxWebsites INTEGER NOT NULL DEFAULT 1
        );
    `);
     try {
        db.exec("SELECT maxWebsites FROM users LIMIT 1");
     } catch (e) {
        console.log("Adding maxWebsites column to users table");
        db.run("ALTER TABLE users ADD COLUMN maxWebsites INTEGER NOT NULL DEFAULT 1");
     }

     db.run(`
        CREATE TABLE IF NOT EXISTS websites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_username TEXT NOT NULL,
            platform TEXT NOT NULL DEFAULT 'wordpress',
            name TEXT NOT NULL,
            url TEXT NOT NULL,
            consumerKey TEXT,
            consumerSecret TEXT,
            shopify_access_token TEXT,
            currency_symbol TEXT NOT NULL DEFAULT '₹',
            is_primary INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (user_username) REFERENCES users (username) ON DELETE CASCADE
        );
     `);
     try {
        db.exec("SELECT platform FROM websites LIMIT 1");
     } catch (e) {
        console.log("Adding Shopify compatibility columns to websites table");
        db.run("ALTER TABLE websites ADD COLUMN platform TEXT NOT NULL DEFAULT 'wordpress'");
        db.run("ALTER TABLE websites ADD COLUMN shopify_access_token TEXT");
     }
     db.run(`CREATE INDEX IF NOT EXISTS idx_websites_user ON websites(user_username);`);

     db.run(`
        CREATE TABLE IF NOT EXISTS workflow_steps (
            id INTEGER PRIMARY KEY,
            step_key TEXT UNIQUE NOT NULL,
            step_name TEXT NOT NULL,
            description TEXT NOT NULL,
            step_order INTEGER NOT NULL,
            is_enabled INTEGER NOT NULL DEFAULT 1,
            is_mandatory INTEGER NOT NULL DEFAULT 0
        );
    `);
    db.run(`
        CREATE TABLE IF NOT EXISTS sync_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_username TEXT NOT NULL,
            sync_timestamp TEXT NOT NULL,
            total_processed INTEGER NOT NULL,
            total_updated INTEGER NOT NULL,
            total_not_found INTEGER NOT NULL,
            total_up_to_date INTEGER NOT NULL,
            total_errors INTEGER NOT NULL,
            FOREIGN KEY (user_username) REFERENCES users (username)
        );
    `);
    db.run(`
        CREATE TABLE IF NOT EXISTS sync_details (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sync_id INTEGER NOT NULL,
            sku TEXT NOT NULL,
            product_name TEXT,
            status TEXT NOT NULL,
            changes_json TEXT,
            FOREIGN KEY (sync_id) REFERENCES sync_history (id)
        );
    `);
    db.run(`
        CREATE TABLE IF NOT EXISTS user_menu_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_username TEXT NOT NULL,
            menu_item_key TEXT NOT NULL,
            is_visible INTEGER NOT NULL,
            FOREIGN KEY (user_username) REFERENCES users(username) ON DELETE CASCADE,
            UNIQUE(user_username, menu_item_key)
        );
    `);
    
    // Seed default users only if users table is empty
    const userCount = db.exec("SELECT count(*) FROM users")[0].values[0][0];
    if (userCount === 0) {
        const defaultUsers = [
            { username: 'admin', password: 'eniac', role: 'admin', syncsRemaining: 999, maxWebsites: 999 },
            { username: 'garg', password: 'garg', role: 'user', syncsRemaining: 30, maxWebsites: 1 },
            { username: 'test', password: 'test', role: 'user', syncsRemaining: 30, maxWebsites: 2 }
        ];
        
        const stmt = db.prepare("INSERT INTO users (username, password, role, syncsRemaining, maxWebsites) VALUES (?, ?, ?, ?, ?)");
        try {
            defaultUsers.forEach(user => {
                stmt.run([user.username, user.password, user.role, user.syncsRemaining, user.maxWebsites]);
            });
        } finally {
            stmt.free();
        }

        const defaultWebsites: Partial<Website>[] = [
             {
                user_username: 'garg',
                platform: 'wordpress',
                name: 'Garg Dastak',
                url: "https://gargdastak.com",
                consumerKey: "ck_af47ca157d65923bb0b4a98699980ff4e562bedf",
                consumerSecret: "cs_48fa7f675331f8cbe0375508f389949845b894d8",
                currency_symbol: '₹',
                is_primary: 1,
            },
            {
                user_username: 'test',
                platform: 'wordpress',
                name: 'iTechServe',
                url: "https://itechserve.co.in",
                consumerKey: "ck_5be8825d128f340c4534e33c94d71ac2824a7f56",
                consumerSecret: "cs_08244be6365404effc944cfeff6e7ed41b6036a5",
                currency_symbol: '₹',
                is_primary: 1,
            },
            {
                user_username: 'test',
                platform: 'shopify',
                name: 'Test Shopify Store',
                url: "zp6rvb-2k",
                shopify_access_token: "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",
                currency_symbol: '$',
                is_primary: 0,
            }
        ];
        const siteStmt = db.prepare("INSERT INTO websites (user_username, platform, name, url, consumerKey, consumerSecret, shopify_access_token, currency_symbol, is_primary) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        try {
            defaultWebsites.forEach(site => {
                siteStmt.run([
                    site.user_username, 
                    site.platform, 
                    site.name, 
                    site.url, 
                    site.consumerKey || null, 
                    site.consumerSecret || null, 
                    site.shopify_access_token || null,
                    site.currency_symbol, 
                    site.is_primary
                ]);
            });
        } finally {
            siteStmt.free();
        }
    }

    // Seed workflow steps only if table is empty
    const stepCount = db.exec("SELECT count(*) FROM workflow_steps")[0].values[0][0];
    if (stepCount === 0) {
        seedWorkflowSteps();
    }
}

/**
 * Initializes the SQLite database, loading from IndexedDB or creating a new one.
 */
export async function initializeDatabase() {
    if (db) return; // Already initialized
    try {
        const SQL = await initSqlJs({
            locateFile: file => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.10.3/${file}`
        });

        const savedDb = await loadDbFromIdb();
        if (savedDb) {
            console.log("Loading database from IndexedDB...");
            db = new SQL.Database(savedDb);
        } else {
            console.log("Creating new database...");
            db = new SQL.Database();
        }
        // Enable foreign key support
        db.exec("PRAGMA foreign_keys = ON;");
        // Always run schema setup to handle upgrades gracefully
        setupSchemaAndSeed();
        await saveDbToIdb();

    } catch (error) {
        console.error("SQLite initialization failed:", error);
        throw error;
    }
}

/**
 * Executes a SQL query that doesn't return data (INSERT, UPDATE, DELETE).
 * Persists the database to IndexedDB after execution.
 */
export async function run(sql: string, params: (string | number | null)[] = []): Promise<void> {
    if (!db) throw new Error("Database not initialized.");
    db.run(sql, params);
    await saveDbToIdb();
}

/**
 * Executes an INSERT SQL query and returns the last inserted row ID.
 * This is a synchronous operation on the in-memory DB.
 * The caller is responsible for persisting the DB to IndexedDB afterwards.
 */
export function runInsertAndGetId(sql: string, params: (string | number | null)[] = []): number {
    if (!db) throw new Error("Database not initialized.");
    
    // Run the insert statement
    db.run(sql, params);

    // Get the last inserted row ID
    // This must be done immediately after the insert on the same connection
    const res = db.exec("SELECT last_insert_rowid()");
    
    if (res.length === 0 || !res[0] || res[0].values.length === 0) {
        return 0;
    }
    // The result is an array of values, e.g., [[123]]
    return res[0].values[0][0] as number;
}


/**
 * Executes a SQL query that returns a single row.
 */
export function get(sql: string, params: (string | number | null)[] = []): any | null {
    if (!db) throw new Error("Database not initialized.");
    const stmt = db.prepare(sql);
    stmt.bind(params);
    const result = stmt.step();
    const row = result ? stmt.getAsObject() : null;
    stmt.free();
    return row;
}

/**
 * Executes a SQL query that returns multiple rows.
 */
export function all(sql: string, params: (string | number | null)[] = []): any[] {
    if (!db) throw new Error("Database not initialized.");
    const stmt = db.prepare(sql);
    stmt.bind(params);
    const results = [];
    while (stmt.step()) {
        results.push(stmt.getAsObject());
    }
    stmt.free();
    return results;
}

/**
 * Executes a batch of SQL statements within a single transaction.
 */
export async function bulkRun(sql: string, paramsArray: any[][]): Promise<void> {
    if (!db) throw new Error("Database not initialized.");

    db.run('BEGIN TRANSACTION');
    try {
        const stmt = db.prepare(sql);
        for (const params of paramsArray) {
            stmt.run(params);
        }
        stmt.free();
        db.run('COMMIT');
    } catch (e) {
        db.run('ROLLBACK');
        throw e;
    }
    
    await saveDbToIdb();
}

/**
 * A utility function to convert query results into a generic format for the database explorer.
 */
export function query(sql: string): { columns: string[], rows: any[][] } {
    if (!db) throw new Error("Database not initialized.");
    const res = db.exec(sql);
    if (res.length === 0) {
        return { columns: [], rows: [] };
    }
    return {
        columns: res[0].columns,
        rows: res[0].values,
    };
}