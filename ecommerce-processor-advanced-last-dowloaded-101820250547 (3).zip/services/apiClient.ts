import type { Website } from '../types/index';

// Assume the execution environment provides a proxy function to bypass CORS for server-to-server APIs like Shopify's.
// This is a common pattern in sandboxed plugin environments.
declare global {
  interface Window {
    proxyFetch: (url: string, options: RequestInit) => Promise<Response>;
  }
}

/**
 * Handles API responses, parsing JSON and throwing a standardized error for non-ok responses.
 */
const handleApiResponse = async (response: Response) => {
    if (!response.ok) {
        let errorBody;
        try {
            errorBody = await response.json();
        } catch (e) {
            // Not a JSON response
        }
        const message = errorBody?.message || errorBody?.errors || response.statusText;
        const platform = response.url.includes('myshopify.com') ? 'Shopify' : 'WooCommerce';
        throw new Error(`${platform} API Error (${response.status}): ${JSON.stringify(message)}`);
    }
    return response; // Return the raw response for further processing (e.g., headers)
};


/**
 * A centralized fetch client to handle API requests for different platforms.
 * It uses a proxy for Shopify to bypass browser CORS limitations.
 * @param website The website configuration object.
 * @param pathOrUrl The API endpoint path (e.g., 'products.json') or a full URL for pagination.
 * @param options Standard Fetch API options.
 * @returns A promise that resolves to the raw Response object.
 */
export const apiFetch = async (website: Website, pathOrUrl: string, options: RequestInit = {}): Promise<Response> => {
    if (website.platform === 'wordpress') {
        if (!website.url || !website.consumerKey || !website.consumerSecret) {
            throw new Error('WooCommerce credentials are not configured for this website.');
        }

        const endpoint = `${website.url}/wp-json/wc/v3/${pathOrUrl}`;
        const url = new URL(endpoint);
        url.searchParams.set('consumer_key', website.consumerKey);
        url.searchParams.set('consumer_secret', website.consumerSecret);
        
        const response = await fetch(url.toString(), options);
        return handleApiResponse(response);

    } else if (website.platform === 'shopify') {
        if (!website.url || !website.shopify_access_token) {
            throw new Error('Shopify credentials are not configured for this website.');
        }
        
        let url: string;
        // Check if we're being passed a full URL (from pagination) or just a path
        if (pathOrUrl.startsWith('https://')) {
            url = pathOrUrl;
        } else {
            const [basePath, queryParams] = pathOrUrl.split('?');
            const finalPath = basePath.endsWith('.json') ? pathOrUrl : `${basePath}.json${queryParams ? `?${queryParams}` : ''}`;
            url = `https://${website.url}.myshopify.com/admin/api/${API_VERSION}/${finalPath}`;
        }
        
        const headers = new Headers(options.headers || {});
        headers.set('Content-Type', 'application/json');
        headers.set('X-Shopify-Access-Token', website.shopify_access_token);
        
        const finalOptions = { ...options, headers };

        // Use the environment's proxy for server-to-server calls to avoid CORS issues.
        if (typeof window.proxyFetch !== 'function') {
             // Fallback to a direct fetch if proxy is not available, which will likely fail but prevents a hard crash.
             console.warn('Proxy fetch function not found. Attempting direct API call to Shopify, which will likely be blocked by CORS.');
             const directResponse = await fetch(url, finalOptions);
             return handleApiResponse(directResponse);
        }
        
        const response = await window.proxyFetch(url, finalOptions);
        return handleApiResponse(response);

    } else {
        throw new Error(`Unsupported platform: ${website.platform}`);
    }
};

const API_VERSION = '2023-10'; // Shared Shopify API version
