import type { Website } from '../types/index';
import type { ShopifyProduct, ShopifyVariant, ShopifyVariantUpdatePayload, ShopifyOrder } from '../types/shopify';
import { apiFetch } from './apiClient';

export const fetchShopifyProductsBySku = async (
    website: Website,
    skus: string[]
): Promise<ShopifyVariant[]> => {
    const skuSet = new Set(skus);
    const foundVariants: ShopifyVariant[] = [];
    let nextUrlOrPath: string | null = 'products.json?limit=250&fields=id,title,variants,images';

    try {
        while (nextUrlOrPath && skuSet.size > 0) {
            const response = await apiFetch(website, nextUrlOrPath);
            const { products } = await response.json();

            if (!products || products.length === 0) break;

            for (const product of products) {
                if (product.variants) {
                    for (const variant of product.variants) {
                        if (variant.sku && skuSet.has(variant.sku)) {
                            foundVariants.push({ ...variant, product_title: product.title });
                            skuSet.delete(variant.sku);
                        }
                    }
                }
            }

            const linkHeader = response.headers.get('Link');
            nextUrlOrPath = linkHeader?.split(',').find(s => s.includes('rel="next"'))?.match(/<(.+)>/)?.[1] || null;
        }
        return foundVariants;
    } catch (error) {
        console.error('Failed to fetch Shopify products:', error);
        throw error;
    }
};

export const batchUpdateShopifyVariants = async (
    website: Website,
    payload: ShopifyVariantUpdatePayload[]
): Promise<{ updatedCount: number; errorDetails: { sku: string; message: string }[] }> => {
    if (payload.length === 0) return { updatedCount: 0, errorDetails: [] };

    let updatedCount = 0;
    const errorDetails: { sku: string; message: string }[] = [];

    for (const item of payload) {
        const path = `variants/${item.variant_id}.json`;
        const body = JSON.stringify({ variant: { id: item.variant_id, price: item.price, compare_at_price: item.compare_at_price } });

        try {
            await apiFetch(website, path, { method: 'PUT', body });
            
            // Shopify inventory is managed separately via Inventory Levels
            const inventoryPath = `inventory_levels/set.json`;
            const inventoryBody = JSON.stringify({
                location_id: 66563342497, // NOTE: This is hardcoded and should be dynamic in a real app
                inventory_item_id: item.inventory_item_id,
                available: item.inventory_quantity
            });
             await apiFetch(website, inventoryPath, { method: 'POST', body: inventoryBody });

            updatedCount++;
        } catch (error) {
            console.error(`Failed to update variant ${item.variant_id}:`, error);
            errorDetails.push({ sku: `variant_id: ${item.variant_id}`, message: (error as Error).message });
        }
    }

    return { updatedCount, errorDetails };
};


export const fetchShopifyOrders = async (
    website: Website,
    fetchUrl: string | null = null
): Promise<{ orders: ShopifyOrder[], nextUrl: string | null }> => {
    const pathOrUrl = fetchUrl || 'orders.json?limit=25&status=any&order=created_at DESC';

    try {
        const response = await apiFetch(website, pathOrUrl);
        const data = await response.json();
        const orders = data.orders;
        
        const linkHeader = response.headers.get('Link');
        const nextUrl = linkHeader?.split(',').find(s => s.includes('rel="next"'))?.match(/<(.+)>/)?.[1] || null;
        
        return { orders, nextUrl };
    } catch (error) {
        console.error('Failed to fetch Shopify orders:', error);
        throw error;
    }
};

export const fetchShopifyOrder = async (
    website: Website,
    orderId: number
): Promise<ShopifyOrder> => {
    try {
        const response = await apiFetch(website, `orders/${orderId}.json`);
        const { order } = await response.json();
        return order;
    } catch (error) {
        console.error(`Failed to fetch Shopify order ${orderId}:`, error);
        throw error;
    }
};

export const cancelShopifyOrder = async (
    website: Website,
    orderId: number
): Promise<ShopifyOrder> => {
    try {
        const response = await apiFetch(website, `orders/${orderId}/cancel.json`, { 
            method: 'POST', 
            body: JSON.stringify({}) 
        });
        const { order } = await response.json();
        return order;
    } catch (error) {
        console.error(`Failed to cancel Shopify order ${orderId}:`, error);
        throw error;
    }
};
