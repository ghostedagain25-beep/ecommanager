import React from 'react';

const AdminUserDetail: React.FC = () => {
    return (
        <div>
            <h2>Admin User Detail</h2>
            <p>This component is not yet implemented.</p>
        </div>
    );
};

export default AdminUserDetail;
