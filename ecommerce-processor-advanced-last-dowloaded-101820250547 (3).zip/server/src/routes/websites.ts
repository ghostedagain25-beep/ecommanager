import express from 'express';
import { Website } from '../models/Website';
import { User } from '../models/User';
import { protect, isAdmin } from '../middleware/auth';

const router = express.Router();

// GET websites for a specific user
router.get('/user/:username', protect, async (req, res) => {
    // Authorization: Admin or the user themselves
    if (req.user?.role !== 'admin' && req.user?.username !== req.params.username) {
        return res.status(403).json({ message: 'Not authorized' });
    }
    try {
        const websites = await Website.find({ user_username: req.params.username });
        res.json(websites);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
});

// POST a new website for a user
router.post('/user/:username', protect, async (req, res) => {
    if (req.user?.role !== 'admin' && req.user?.username !== req.params.username) {
        return res.status(403).json({ message: 'Not authorized' });
    }
    try {
        const user = await User.findOne({ username: req.params.username });
        if (!user) return res.status(404).json({ message: 'User not found' });
        
        const websites = await Website.find({ user_username: req.params.username });
        if (websites.length >= user.maxWebsites) {
            return res.status(403).json({ message: 'User has reached their maximum website limit' });
        }

        const isFirstWebsite = websites.length === 0;

        const newWebsite = new Website({
            ...req.body,
            user_username: req.params.username,
            is_primary: isFirstWebsite,
        });

        const savedWebsite = await newWebsite.save();
        res.status(201).json(savedWebsite);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
});

// PUT update a website
router.put('/:id', protect, async (req, res) => {
    try {
        const website = await Website.findById(req.params.id);
        if (!website) return res.status(404).json({ message: 'Website not found' });

        if (req.user?.role !== 'admin' && req.user?.username !== website.user_username) {
            return res.status(403).json({ message: 'Not authorized' });
        }

        Object.assign(website, req.body);
        const updatedWebsite = await website.save();
        res.json(updatedWebsite);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
});

// DELETE a website
router.delete('/:id', protect, async (req, res) => {
    try {
        const website = await Website.findById(req.params.id);
        if (!website) return res.status(404).json({ message: 'Website not found' });

        if (req.user?.role !== 'admin' && req.user?.username !== website.user_username) {
            return res.status(403).json({ message: 'Not authorized' });
        }
        
        await Website.deleteOne({ _id: req.params.id });

        if (website.is_primary) {
            const remaining = await Website.findOne({ user_username: website.user_username });
            if (remaining) {
                remaining.is_primary = true;
                await remaining.save();
            }
        }
        res.status(204).send();
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
});

// POST set primary website
router.post('/user/:username/primary/:websiteId', protect, async (req, res) => {
     if (req.user?.role !== 'admin' && req.user?.username !== req.params.username) {
        return res.status(403).json({ message: 'Not authorized' });
    }
    try {
        await Website.updateMany({ user_username: req.params.username }, { is_primary: false });
        await Website.updateOne({ _id: req.params.websiteId, user_username: req.params.username }, { is_primary: true });
        res.status(204).send();
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
});

export default router;
