import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import authRoutes from './routes/auth';
import userRoutes from './routes/users';
import websiteRoutes from './routes/websites';
import workflowRoutes from './routes/workflow';
import syncsRoutes from './routes/syncs';
import adminRoutes from './routes/admin';
import { seedDatabase } from './seed';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/websites', websiteRoutes);
app.use('/api/workflow', workflowRoutes);
app.use('/api/syncs', syncsRoutes);
app.use('/api/admin', adminRoutes);

app.get('/', (req, res) => {
    res.send('StockPro Server is running.');
});

// Connect to MongoDB and start server
const MONGO_URI = process.env.MONGO_URI;
if (!MONGO_URI) {
    console.error('FATAL ERROR: MONGO_URI is not defined in .env file.');
    // FIX: Cast process to any to resolve TypeScript type error.
    (process as any).exit(1);
}

mongoose.connect(MONGO_URI)
    .then(() => {
        console.log('MongoDB connected successfully.');
        // Seed the database if it's empty
        seedDatabase();
        app.listen(PORT, () => {
            console.log(`Server is running on http://localhost:${PORT}`);
        });
    })
    .catch(err => {
        console.error('MongoDB connection error:', err);
        // FIX: Cast process to any to resolve TypeScript type error.
        (process as any).exit(1);
    });
